CREATE TABLE transcriptions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    session_id UUID REFERENCES sessions(id) ON DELETE CASCADE NOT NULL,
    text TEXT,
    assembly_ai_job_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);
CREATE INDEX idx_transcriptions_session_id ON transcriptions(session_id); 
CREATE INDEX idx_transcriptions_assembly_ai_job_id ON transcriptions(assembly_ai_job_id);